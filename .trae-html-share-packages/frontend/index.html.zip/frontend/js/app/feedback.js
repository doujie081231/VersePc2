/**
 * @file feedback.js
 * @description 问题反馈页 - 表单状态、附件管理、环境信息采集与提交
 *
 * 提交链路目前只到 sendFeedbackToSite()，站点接口确定后只需补这一个函数，
 * 其余（校验、附件、环境信息、按钮状态）无需改动。
 */

/** 站点地址 */
var FEEDBACK_SITE_URL = 'https://verselauncher.cn';

/** 附件限制 */
var FEEDBACK_MAX_FILES = 10;
var FEEDBACK_MAX_FILE_BYTES = 20 * 1024 * 1024;

/** 表单状态 */
var feedbackState = {
  type: 'bug',
  files: [],
  env: null,
  envLoaded: false,
  submitting: false
};

/* ============================================================================
   初始化
   ============================================================================ */

/** 绑定拖拽区、采集环境信息并同步按钮状态（Vue 挂载完成后调用） */
function setupFeedback() {
  var drop = document.getElementById('fb-drop');
  if (drop) {
    drop.addEventListener('dragover', function (e) {
      e.preventDefault();
      drop.classList.add('drag-over');
    });
    drop.addEventListener('dragleave', function () {
      drop.classList.remove('drag-over');
    });
    drop.addEventListener('drop', function (e) {
      e.preventDefault();
      drop.classList.remove('drag-over');
      if (e.dataTransfer && e.dataTransfer.files) {
        addFeedbackFiles(e.dataTransfer.files);
      }
    });
  }

  onFeedbackDetailInput();
  renderFeedbackFiles();
  updateFeedbackSubmitState();
  loadFeedbackEnv();
}

/* ============================================================================
   反馈类型
   ============================================================================ */

function selectFeedbackType(btn) {
  if (!btn) return;
  var group = document.getElementById('fb-type-group');
  if (group) {
    group.querySelectorAll('.fb-type-btn').forEach(function (b) { b.classList.remove('active'); });
  }
  btn.classList.add('active');
  feedbackState.type = btn.dataset.type || 'other';
  updateFeedbackSubmitState();
}

function getFeedbackTypeLabel(type) {
  if (type === 'bug') return '问题反馈';
  if (type === 'feature') return '功能建议';
  return '其他';
}

/* ============================================================================
   附件
   ============================================================================ */

function pickFeedbackFiles() {
  var input = document.getElementById('fb-file-input');
  if (input) input.click();
}

function onFeedbackFilesPicked(fileList) {
  addFeedbackFiles(fileList);
  var input = document.getElementById('fb-file-input');
  if (input) input.value = '';
}

function addFeedbackFiles(fileList) {
  var incoming = Array.prototype.slice.call(fileList || []);
  var rejected = [];

  incoming.forEach(function (file) {
    if (feedbackState.files.length >= FEEDBACK_MAX_FILES) {
      rejected.push(file.name + '（已达数量上限）');
      return;
    }
    if (file.size > FEEDBACK_MAX_FILE_BYTES) {
      rejected.push(file.name + '（超过 20 MB）');
      return;
    }
    var duplicated = feedbackState.files.some(function (item) {
      return item.name === file.name && item.size === file.size;
    });
    if (duplicated) return;
    feedbackState.files.push({ name: file.name, size: file.size, file: file });
  });

  if (rejected.length && typeof showToast === 'function') {
    showToast('已跳过：' + rejected.join('、'), 'error');
  }
  renderFeedbackFiles();
  updateFeedbackSubmitState();
}

function removeFeedbackFile(index) {
  feedbackState.files.splice(index, 1);
  renderFeedbackFiles();
  updateFeedbackSubmitState();
}

function renderFeedbackFiles() {
  var list = document.getElementById('fb-file-list');
  if (!list) return;

  if (!feedbackState.files.length) {
    list.innerHTML = '';
    return;
  }

  list.innerHTML = feedbackState.files.map(function (item, index) {
    return '<div class="fb-file-item">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fb-file-icon">' +
      '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>' +
      '<span class="fb-file-name" title="' + escapeFeedbackText(item.name) + '">' + escapeFeedbackText(item.name) + '</span>' +
      '<span class="fb-file-size">' + formatFeedbackSize(item.size) + '</span>' +
      '<button class="fb-file-remove" title="移除" onclick="removeFeedbackFile(' + index + ')">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
      '</button>' +
      '</div>';
  }).join('');
}

function formatFeedbackSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

function escapeFeedbackText(text) {
  return String(text == null ? '' : text).replace(/[&<>"']/g, function (ch) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
  });
}

/* ============================================================================
   环境信息
   ============================================================================ */

function onFeedbackDetailInput() {
  var detail = document.getElementById('fb-detail');
  var counter = document.getElementById('fb-detail-counter');
  if (detail && counter) counter.textContent = detail.value.length + ' / 2000';
  updateFeedbackSubmitState();
}

async function loadFeedbackEnv() {
  if (feedbackState.envLoaded) {
    renderFeedbackEnv();
    return;
  }

  var env = {
    launcher: '未知',
    system: '未知',
    java: '未知'
  };

  try {
    var api = window.electronAPI;
    if (api && api.updater && typeof api.updater.getVersion === 'function') {
      var version = await api.updater.getVersion();
      if (version) env.launcher = 'VersePC2 ' + version;
    }
  } catch (e) {}

  try {
    var platform = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '';
    var arch = /x64|Win64|WOW64|x86_64/i.test(navigator.userAgent) ? '64 位' : '';
    env.system = platform ? (platform + (arch ? ' · ' + arch : '')) : navigator.userAgent;
  } catch (e) {}

  try {
    if (typeof API !== 'undefined' && typeof API.detectJava === 'function') {
      var result = await API.detectJava();
      var list = (result && result.javaList) || [];
      if (list.length) {
        var best = list.find(function (j) { return j.majorVersion >= 17; }) || list[0];
        env.java = 'Java ' + (best.version || best.majorVersion || '') +
          (best.is64Bit ? ' (64 位)' : '') +
          (best.path ? ' · ' + best.path : '');
      } else {
        env.java = '未检测到';
      }
    }
  } catch (e) {}

  feedbackState.env = env;
  feedbackState.envLoaded = true;
  renderFeedbackEnv();
}

function renderFeedbackEnv() {
  var list = document.getElementById('fb-env-list');
  if (!list) return;
  var env = feedbackState.env;
  if (!env) {
    list.innerHTML = '<div class="fb-env-empty">正在收集环境信息...</div>';
    return;
  }

  var rows = [
    ['启动器版本', env.launcher],
    ['操作系统', env.system],
    ['Java', env.java]
  ];

  list.innerHTML = rows.map(function (row) {
    return '<div class="fb-env-row">' +
      '<span class="fb-env-key">' + row[0] + '</span>' +
      '<span class="fb-env-value" title="' + escapeFeedbackText(row[1]) + '">' + escapeFeedbackText(row[1]) + '</span>' +
      '</div>';
  }).join('');
}

/* ============================================================================
   提交
   ============================================================================ */

function getFeedbackForm() {
  return {
    type: feedbackState.type,
    typeLabel: getFeedbackTypeLabel(feedbackState.type),
    title: (document.getElementById('fb-title') || {}).value || '',
    detail: (document.getElementById('fb-detail') || {}).value || '',
    contact: (document.getElementById('fb-contact') || {}).value || '',
    captcha: (document.getElementById('fb-captcha-input') || {}).value || ''
  };
}

/** 返回第一条校验错误，全部通过时返回空字符串 */
function validateFeedback(form) {
  if (!form.title.trim()) return '请填写反馈标题';
  if (form.title.trim().length < 4) return '标题太短，请至少填写 4 个字';
  if (!form.detail.trim()) return '请填写详细描述';
  if (form.detail.trim().length < 10) return '描述太短，请至少填写 10 个字';

  var captchaGroup = document.getElementById('fb-captcha-group');
  if (captchaGroup && !captchaGroup.hidden && !form.captcha.trim()) {
    return '请完成人机验证';
  }
  return '';
}

function updateFeedbackSubmitState() {
  var button = document.getElementById('fb-submit-btn');
  var hint = document.getElementById('fb-submit-hint');
  if (!button) return;

  if (feedbackState.submitting) {
    button.disabled = true;
    return;
  }

  var error = validateFeedback(getFeedbackForm());
  button.disabled = !!error;
  if (hint) hint.textContent = error || '';
  if (hint) hint.classList.toggle('is-error', !!error);
}

function setFeedbackSubmitting(submitting) {
  feedbackState.submitting = submitting;
  var button = document.getElementById('fb-submit-btn');
  if (button) {
    button.disabled = submitting;
    button.textContent = submitting ? '提交中...' : '提交反馈';
  }
}

function resetFeedbackForm() {
  var title = document.getElementById('fb-title');
  var detail = document.getElementById('fb-detail');
  var contact = document.getElementById('fb-contact');
  if (title) title.value = '';
  if (detail) detail.value = '';
  if (contact) contact.value = '';

  feedbackState.files = [];
  feedbackState.type = 'bug';
  var group = document.getElementById('fb-type-group');
  if (group) {
    group.querySelectorAll('.fb-type-btn').forEach(function (b) {
      b.classList.toggle('active', b.dataset.type === 'bug');
    });
  }

  renderFeedbackFiles();
  onFeedbackDetailInput();
}

async function submitFeedback() {
  if (feedbackState.submitting) return;

  var form = getFeedbackForm();
  var error = validateFeedback(form);
  if (error) {
    updateFeedbackSubmitState();
    if (typeof showToast === 'function') showToast(error, 'error');
    return;
  }

  var includeEnv = document.getElementById('fb-include-env');
  var payload = {
    type: form.type,
    typeLabel: form.typeLabel,
    title: form.title.trim(),
    detail: form.detail.trim(),
    contact: form.contact.trim(),
    captcha: form.captcha.trim(),
    env: (includeEnv && includeEnv.checked) ? feedbackState.env : null,
    files: feedbackState.files.map(function (item) { return item.file; })
  };

  setFeedbackSubmitting(true);
  try {
    await sendFeedbackToSite(payload);
    setFeedbackSubmitting(false);
    resetFeedbackForm();
    if (typeof showToast === 'function') showToast('反馈已提交，感谢你的反馈！', 'success');
  } catch (e) {
    setFeedbackSubmitting(false);
    updateFeedbackSubmitState();
    if (typeof showToast === 'function') showToast(e && e.message ? e.message : '提交失败，请稍后重试', 'error');
  }
}

/**
 * 提交到站点 —— 唯一的对接点。
 *
 * 目前站点接口尚未接入，因此直接抛出提示。接入时需要补齐：
 *   1. 请求地址与方式（POST 到 verselauncher.cn 的哪个路径）
 *   2. 字段命名（type / title / detail / contact / env 如何对应）
 *   3. 附件传输方式（multipart/form-data 还是先上传拿到附件 id）
 *   4. 人机验证流程（验证码图片从哪里取、提交时带什么参数）
 * 接入后，若站点要求人机验证，再取消 #fb-captcha-group 的 hidden。
 *
 * @param {Object} payload 已校验的表单数据，files 为 File 数组
 */
async function sendFeedbackToSite(payload) {
  void payload;
  throw new Error('反馈提交通道尚未接入站点接口');
}

/** 人机验证：接入站点验证码接口后渲染验证码图片 */
function refreshFeedbackCaptcha() {
  // 验证码由站点接口下发，接入前该区域保持隐藏，此处不做处理
}

function openFeedbackSite() {
  var api = window.electronAPI;
  if (api && typeof api.openExternal === 'function') {
    api.openExternal(FEEDBACK_SITE_URL).catch(function () {});
    return;
  }
  window.open(FEEDBACK_SITE_URL, '_blank');
}