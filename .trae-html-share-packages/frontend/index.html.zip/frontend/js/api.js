/**
 * VersePC - Minecraft Launcher
 * Copyright (c) 2026 豆杰
 * SPDX-License-Identifier: GPL-3.0-only
 */

/* api.js — VersePC 前端 API 通信层
 * 封装所有与本地后端服务器(Express)的 HTTP 通信
 * 通过 fetch API 调用后端路由，统一管理所有网络请求
 */

/* 统一错误类型体系 */

class ApiError extends Error {
    constructor(message, code, originalError = null) {
        super(message);
        this.name = 'ApiError';
        this.code = code;
        this.originalError = originalError;
        this.timestamp = Date.now();
    }
}

class NetworkError extends ApiError {
    constructor(message, originalError = null) {
        super(message, 'NETWORK_ERROR', originalError);
        this.name = 'NetworkError';
    }
}

class ServerError extends ApiError {
    constructor(message, statusCode, originalError = null) {
        super(message, `SERVER_ERROR_${statusCode}`, originalError);
        this.name = 'ServerError';
        this.statusCode = statusCode;
    }
}

class ClientError extends ApiError {
    constructor(message, statusCode, originalError = null) {
        super(message, `CLIENT_ERROR_${statusCode}`, originalError);
        this.name = 'ClientError';
        this.statusCode = statusCode;
    }
}

class TimeoutError extends NetworkError {
    constructor(message = '请求超时，请检查网络连接') {
        super(message);
        this.name = 'TimeoutError';
        this.code = 'TIMEOUT_ERROR';
    }
}

/* 错误消息映射与转换 */

const ERROR_MESSAGES = {
    'NETWORK_ERROR': '网络连接失败，请检查网络设置',
    'TIMEOUT_ERROR': '请求超时，请检查网络连接后重试',
    'CLIENT_ERROR_400': '请求参数错误',
    'CLIENT_ERROR_401': '未授权，请重新登录',
    'CLIENT_ERROR_403': '没有权限执行此操作',
    'CLIENT_ERROR_404': '请求的资源不存在',
    'CLIENT_ERROR_409': '操作冲突，请刷新后重试',
    'CLIENT_ERROR_429': '请求过于频繁，请稍后再试',
    'SERVER_ERROR_500': '服务器内部错误，请稍后重试',
    'SERVER_ERROR_502': '网关错误，服务暂时不可用',
    'SERVER_ERROR_503': '服务维护中，请稍后访问',
    'SERVER_ERROR_504': '网关超时，请稍后重试',
    'PARSE_ERROR': '数据解析失败',
    'UNKNOWN_ERROR': '未知错误，请稍后重试'
};

function getUserFriendlyMessage(error) {
    if (error instanceof ApiError) {
        return ERROR_MESSAGES[error.code] || error.message;
    }
    return ERROR_MESSAGES['UNKNOWN_ERROR'];
}

/* 全局错误处理器 */

const ErrorHandler = {
    handle(error, context = {}) {
        console.error(`[API Error] ${context.action || 'Unknown'}:`, error);

        const userMessage = getUserFriendlyMessage(error);

        if (error instanceof TimeoutError || error instanceof NetworkError) {
            if (typeof showToast === 'function') showToast(userMessage, 'warning');
        } else if (error instanceof ClientError && error.statusCode === 401) {
            if (typeof showToast === 'function') showToast('登录已过期，请重新登录', 'error');
        } else if (error instanceof ServerError) {
            if (typeof showToast === 'function') showToast(userMessage, 'error');
        } else {
            if (typeof showToast === 'function') showToast(userMessage, 'error');
        }
    }
};

// 后端服务器基地址（空字符串表示同源请求）
const API_BASE = '';

/* Tauri 环境检测 — 在 Tauri 下 API 走 invoke('api_proxy') 而非 fetch */
const _isTauri = !!(window.__TAURI__ || window.__TAURI_INTERNALS__ || window.__TAURI_PROXY__);

async function _tauriApiProxy(method, path, params, body) {
    // 30 秒超时，防止 Rust 端卡住时 init 流程永远阻塞
    const _timeoutMs = 30000;
    let _timer = null;
    const _timeoutP = new Promise((_, reject) => {
        _timer = setTimeout(() => reject(new Error('API 超时: ' + path)), _timeoutMs);
    });

    const _work = (async () => {
        // 统一走单一桥接面 window.bridge.apiProxy（tauri-bridge.js 建立）
        const apiProxy =
            (window.bridge && window.bridge.apiProxy) ||
            (window.__TAURI_PROXY__ && window.__TAURI_PROXY__.apiProxy);
        if (apiProxy) {
            return await apiProxy(method, path, params, body);
        }
        // 兜底：直接 invoke（Tauri v2 的 __TAURI_INTERNALS__ 没有 .core，invoke 在自身）
        const core = (window.__TAURI__ && window.__TAURI__.core) ||
                     window.__TAURI_INTERNALS__;
        if (core && core.invoke) {
            const result = await core.invoke('api_proxy', { method, path, params: params || {}, body: body || null });
            return {
                ok: result.status < 400,
                status: result.status,
                json: () => Promise.resolve(result.body)
            };
        }
        throw new Error('[API] 统一桥接层 window.bridge 不可用');
    })();

    try {
        return await Promise.race([_work, _timeoutP]);
    } finally {
        if (_timer) clearTimeout(_timer);
    }
}

function _isApiPath(path) {
    return path.startsWith('/api/');
}

/* 底层网络工具函数 */

/**
 * 带超时的 fetch 包装器
 * @param {string} url - 请求地址
 * @param {Object} options - fetch 配置项
 * @param {number} timeout - 超时时间（毫秒），默认 30 秒
 * @returns {Promise<Response>} fetch 响应
 * @throws {TimeoutError} 请求超时时抛出
 * @throws {NetworkError} 网络连接失败时抛出
 */
async function fetchWithTimeout(url, options = {}, timeout = 30000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort('timeout'), timeout);
    
    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        return response;
    } catch (e) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') {
            throw new TimeoutError();
        }
        throw new NetworkError('网络连接失败', e);
    }
}

/**
 * 通用 GET 请求，自动拼接 URL 查询参数
 * @param {string} path - API 路径（如 /api/versions）
 * @param {Object} params - 查询参数对象
 * @param {number} timeout - 超时时间（毫秒）
 * @returns {Promise<Object>} 解析后的 JSON 响应
 */
async function apiGet(path, params = {}, timeout = 30000) {
    // Tauri 环境：走 invoke('api_proxy')
    if (_isTauri && _isApiPath(path)) {
        try {
            const res = await _tauriApiProxy('GET', path, params, null);
            if (!res.ok) {
                const body = await res.json();
                const errMsg = body && body.error ? body.error : `HTTP ${res.status}`;
                if (res.status >= 500) throw new ServerError(errMsg, res.status);
                if (res.status >= 400) throw new ClientError(errMsg, res.status);
            }
            return await res.json();
        } catch (e) {
            if (e instanceof ApiError) throw e;
            console.error(`API GET ${path} failed:`, e);
            throw new ApiError('请求失败', 'UNKNOWN_ERROR', e);
        }
    }
    // Electron/浏览器环境：走 fetch
    const query = new URLSearchParams(params).toString();
    const url = `${API_BASE}${path}${query ? '?' + query : ''}`;
    try {
        const res = await fetchWithTimeout(url, {}, timeout);
        if (!res.ok) {
            let errMsg = `HTTP ${res.status}`;
            try { const body = await res.json(); if (body.error) errMsg = body.error; } catch (e) {}
            if (res.status >= 500) throw new ServerError(errMsg, res.status);
            if (res.status >= 400) throw new ClientError(errMsg, res.status);
        }
        return await res.json();
    } catch (e) {
        if (e instanceof ApiError) throw e;
        console.error(`API GET ${path} failed:`, e);
        throw new ApiError('请求失败', 'UNKNOWN_ERROR', e);
    }
}

/**
 * 通用 POST 请求，自动设置 JSON 请求头
 * @param {string} path - API 路径
 * @param {Object} data - 请求体数据
 * @param {number} timeout - 超时时间（毫秒）
 * @returns {Promise<Object>} 解析后的 JSON 响应
 */
async function apiPost(path, data = {}, timeout = 30000) {
    // Tauri 环境：走 invoke('api_proxy')
    if (_isTauri && _isApiPath(path)) {
        try {
            const res = await _tauriApiProxy('POST', path, {}, data);
            if (!res.ok) {
                const body = await res.json();
                const errMsg = body && body.error ? body.error : `HTTP ${res.status}`;
                if (res.status >= 500) throw new ServerError(errMsg, res.status);
                if (res.status >= 400) throw new ClientError(errMsg, res.status);
            }
            return await res.json();
        } catch (e) {
            if (e instanceof ApiError) throw e;
            console.error(`API POST ${path} failed:`, e);
            throw new ApiError('请求失败', 'UNKNOWN_ERROR', e);
        }
    }
    // Electron/浏览器环境：走 fetch
    try {
        const res = await fetchWithTimeout(`${API_BASE}${path}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        }, timeout);
        if (!res.ok) {
            let errMsg = `HTTP ${res.status}`;
            try { const body = await res.json(); if (body.error) errMsg = body.error; } catch (e) {}
            if (res.status >= 500) throw new ServerError(errMsg, res.status);
            if (res.status >= 400) throw new ClientError(errMsg, res.status);
        }
        return await res.json();
    } catch (e) {
        if (e instanceof ApiError) throw e;
        console.error(`API POST ${path} failed:`, e);
        throw new ApiError('请求失败', 'UNKNOWN_ERROR', e);
    }
}

/**
 * 通用 DELETE 请求
 * @param {string} path - API 路径
 * @param {Object} data - 请求体数据
 * @returns {Promise<Object>} 解析后的 JSON 响应
 */
async function apiDelete(path, data = {}) {
    // Tauri 环境：走 invoke('api_proxy')
    if (_isTauri && _isApiPath(path)) {
        try {
            const res = await _tauriApiProxy('DELETE', path, {}, data);
            if (!res.ok) {
                const body = await res.json();
                const errMsg = body && body.error ? body.error : `HTTP ${res.status}`;
                if (res.status >= 500) throw new ServerError(errMsg, res.status);
                if (res.status >= 400) throw new ClientError(errMsg, res.status);
            }
            return await res.json();
        } catch (e) {
            if (e instanceof ApiError) throw e;
            console.error(`API DELETE ${path} failed:`, e);
            throw new ApiError('请求失败', 'UNKNOWN_ERROR', e);
        }
    }
    // Electron/浏览器环境：走 fetch
    try {
        const res = await fetchWithTimeout(`${API_BASE}${path}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!res.ok) {
            let errMsg = `HTTP ${res.status}`;
            try { const body = await res.json(); if (body.error) errMsg = body.error; } catch (e) {}
            if (res.status >= 500) throw new ServerError(errMsg, res.status);
            if (res.status >= 400) throw new ClientError(errMsg, res.status);
        }
        return await res.json();
    } catch (e) {
        if (e instanceof ApiError) throw e;
        console.error(`API DELETE ${path} failed:`, e);
        throw new ApiError('请求失败', 'UNKNOWN_ERROR', e);
    }
}

/* API 接口对象 — 按功能模块分组
 * 所有方法均返回 Promise，由调用方处理异步逻辑
 */

const API = {
    // === 系统信息 ===
    getSystemMemory: () => apiGet('/api/system/memory'),
    memoryOptimize: () => window.bridge?.memoryOptimize?.() || Promise.reject(new Error('记忆优化能力不可用')),

    // === 游戏版本管理 ===
    getVersions: (refresh = false) => apiGet('/api/versions', { refresh: refresh ? 'true' : '' }),
    deleteVersion: (versionId, permanent) => apiPost('/api/version/delete', { versionId, permanent: !!permanent }),
    getDeleteChain: (versionId) => apiPost('/api/version/delete-chain', { versionId }),
    openVersionFolder: (versionId, folderType) => apiGet('/api/version/open-folder', { versionId, folderType }),
    getVersionExportInfo: (versionId) => apiGet('/api/version/export-info', { versionId }),

    // === 版本安装 ===
    installVersion: (url, versionId, loaderInfo = null, downloadSource = 'mojang', customName = '') =>
        apiPost('/api/install-start', { url, versionId, loaderInfo, downloadSource, customName }),
    checkVersionName: (name) =>
        apiPost('/api/check-version-name', { name }),
    getInstallProgress: (sessionId, sse = false) =>
        apiGet('/api/install-progress', { sessionId, sse: sse ? 'true' : '' }),
    cancelInstall: (sessionId) => apiGet('/api/install-cancel', { sessionId }),

    // === 模组管理 ===
    getInstalledMods: () => apiGet('/api/mods'),
    searchMods: (query, source = 'any', loader = '', version = '', category = '', sort = 'relevance', limit = 15, offset = 0) =>
        apiGet('/api/mods/search', { query, source, loader, version, category, sort, limit, offset }),
    downloadMod: (projectId, source = 'modrinth', loader = '', mcVersion = '') =>
        apiPost('/api/mods/download', { projectId, source, loader, mcVersion }),
    downloadModVersion: (versionId, projectId, source = 'modrinth', fileId = '', gameVersion = '', loader = '', savePath = '', includeDeps = true) =>
        apiPost('/api/mods/download-version', { versionId, projectId, source, fileId, gameVersion, loader, savePath, includeDeps }),
    getModDownloadStatus: (sessionId) => apiGet('/api/mods/download-status', { sessionId }),
    getModDetail: (projectId, source = 'modrinth') => apiGet('/api/mods/detail', { projectId, source }),
    getResourceImage: (url) => apiGet('/api/resource-image', { url }),
    getModIcon: (hash) => apiGet('/api/mod-icon', { hash }),
    getModVersions: (projectId, source = 'modrinth', loader = '', gameVersion = '') =>
        apiGet('/api/mods/versions', { projectId, source, loader, gameVersion }),
    getModCategories: (source = 'modrinth') => apiGet('/api/mods/categories', { source }),
    toggleMod: (modId, enabled, versionId) => apiPost('/api/mods/toggle', { modId, enabled, versionId }),
    deleteMod: (modId) => apiPost('/api/mods/delete', { modId }),
    getVersionMods: (versionId) => apiGet('/api/mods/installed', { versionId }),
    selectModFile: () => apiGet('/api/mods/select-file'),
    selectModpackFile: () => apiGet('/api/mods/select-modpack-file'),
    installModFromFile: (versionId, filePath) => apiPost('/api/mods/install-from-file', { versionId, filePath }),
    removeMod: (versionId, fileName) => apiPost('/api/mods/remove', { versionId, fileName }),
    resolveModDeps: (ids, source = 'modrinth') => apiGet('/api/mods/resolve-deps', { ids, source }),
    resolveDepVersions: (ids, gameVersion = '', loader = '', source = 'modrinth') =>
        apiPost('/api/mods/resolve-deps-versions', { ids, gameVersion, loader, source }),
    selectSaveFolder: async (defaultPath = '') => {
        try {
            if (window.electronAPI?.selectSaveFolder) {
                return await window.electronAPI.selectSaveFolder(defaultPath);
            }
        } catch (e) {
            console.warn('[API] IPC selectSaveFolder failed, falling back to server:', e.message);
        }
        return await apiPost('/api/mods/select-save-folder', { defaultPath });
    },

    // === 收藏夹管理 ===
    getFavorites: () => apiGet('/api/favorites'),
    createFavorite: (name) => apiPost('/api/favorites/create', { name }),
    renameFavorite: (id, name) => apiPost('/api/favorites/rename', { id, name }),
    deleteFavorite: (id) => apiPost('/api/favorites/delete', { id }),
    addToFavorite: (favId, projectId) => apiPost('/api/favorites/add', { favId, projectId }),
    removeFromFavorite: (favId, projectId) => apiPost('/api/favorites/remove', { favId, projectId }),
    updateFavNote: (favId, projectId, note) => apiPost('/api/favorites/note', { favId, projectId, note }),
    importFavorite: (data, targetFavId) => apiPost('/api/favorites/import', { data, targetFavId }),

    // === 模组加载器（Fabric/Forge/NeoForge/OptiFine）===
    getModLoaderVersions: async (gameVersion, loaderType) => {
        try {
            let result;
            switch (loaderType.toLowerCase()) {
                case 'forge':       result = await API.getForgeVersions(gameVersion); break;
                case 'neoforge':    result = await apiGet('/api/neoforge/versions', { game: gameVersion }); break;
                case 'fabric':      result = await API.getFabricVersions(gameVersion); break;
                case 'optifine':    result = await API.getOptiFineVersions(gameVersion); break;
                default:            return [];
            }
            if (result && result.versions) return result.versions;
            return Array.isArray(result) ? result : [];
        } catch (e) {
            console.error('getModLoaderVersions error:', e);
            return [];
        }
    },
    getFabricVersions: async (game = '') => {
        const result = await apiGet('/api/fabric/versions', { game });
        return result && result.versions ? result.versions : (Array.isArray(result) ? result : []);
    },
    installFabric: (gameVersion, loaderVersion = '') =>
        apiPost('/api/fabric/install', { gameVersion, loaderVersion }, 120000),
    getFabricApiVersions: async (gameVersion) => {
        const result = await apiGet('/api/fabric-api/versions', { game: gameVersion });
        return result || { versions: [], recommended: '' };
    },
    installFabricApi: (gameVersion, versionId, versionName = '', fileUrl = '', filename = '') =>
        apiPost('/api/fabric-api/install', { gameVersion, versionId, versionName, fileUrl, filename }, 180000),
    getForgeVersions: async (game) => {
        const result = await apiGet('/api/forge/versions', { game });
        return result && result.versions ? result.versions : (Array.isArray(result) ? result : []);
    },
    installForge: (gameVersion, forgeVersion) =>
        apiPost('/api/forge/install', { gameVersion, forgeVersion }, 300000),
    installNeoForge: (gameVersion, neoVersion) =>
        apiPost('/api/neoforge/install', { gameVersion, neoVersion }, 300000),
    getOptiFineVersions: async (game) => {
        const result = await apiGet('/api/optifine/versions', { game });
        return result && result.versions ? result.versions : (Array.isArray(result) ? result : []);
    },

    // === 游戏启动与生命周期 ===
    launchGame: (versionId, options, timeout) => apiPost('/api/launch', { versionId, ...(options || {}) }, timeout),
    cancelLaunch: () => apiPost('/api/launch/cancel'),
    launchCheck: (versionId, externalVersionDir) => apiPost('/api/launch/check', { versionId, externalVersionDir }),
    downloadLaunchDeps: (versionId, sessionId, timeout) =>
        apiPost('/api/launch/download-deps', { versionId, sessionId }, timeout || 180000),
    getLaunchSessionStatus: (sessionId) => apiGet('/api/launch/session-status', { sessionId }),
    getGameStatus: () => apiGet('/api/game/status'),
    stopGameInstance: (sessionId) => apiPost('/api/game/stop', { sessionId }),
    cleanupScan: () => apiPost('/api/cleanup/scan'),
    cleanupRun: () => apiPost('/api/cleanup'),
    getExitAnalysis: () => apiGet('/api/game/exit-analysis'),
    analyzeCrash: (versionId) => apiGet('/api/game/crash-analyze', { versionId }),
    exportLaunchScript: (versionId) => apiPost('/api/version/export-script', { versionId }),

    // === 版本修复 ===
    repairStart: (versionId) => apiPost('/api/version/repair-start', { versionId }),
    repairProgress: (sessionId, sse = false) =>
        apiGet('/api/version/repair-progress', { sessionId, sse: sse ? 'true' : '' }),
    repairCancel: (sessionId) => apiGet('/api/version/repair-cancel', { sessionId }),
    diagnoseVersion: (versionId) => apiGet('/api/version/diagnose', { versionId }),

    // === 版本配置（独立/隔离设置）===
    getVersionSettings: (versionId) => apiGet('/api/version/settings', { versionId }),
    saveVersionSettings: (settings) => apiPost('/api/version/settings/save', settings),

    // === 设置管理 ===
    getSettings: () => apiGet('/api/settings'),
    saveSettings: (settings) => apiPost('/api/settings', settings),
    resetSettings: () => apiPost('/api/settings/reset', {}),
    saveSetting: (key, value) => apiPost('/api/settings/set', { key, value }),
    getDataDir: () => apiGet('/api/settings/data-dir'),
    setDataDir: (dataDir) => apiPost('/api/settings/data-dir', { dataDir }),
    resetDataDir: () => apiPost('/api/settings/data-dir', { reset: true }),

    // === 账户管理（离线/Microsoft/外置登录）===
    getAccounts: () => apiGet('/api/accounts'),
    addOfflineAccount: (username) => apiPost('/api/accounts/add-offline', { username }),
    deleteAccount: (accountId) => apiPost('/api/accounts/delete', { accountId }),
    selectAccount: (accountId) => apiPost('/api/accounts/select', { accountId }),
    loginThirdParty: (serverUrl, username, password) =>
        apiPost('/api/accounts/thirdparty-login', { serverUrl, username, password }),
    verifyThirdPartyServer: (serverUrl) =>
        apiGet('/api/accounts/thirdparty-verify', { serverUrl }),
    selectThirdPartyProfile: (accessToken, clientToken, serverUrl, profileId, profileName) =>
        apiPost('/api/accounts/thirdparty-select-profile', { accessToken, clientToken, serverUrl, profileId, profileName }),

    // === Microsoft 认证 ===
    getMsDeviceCode: () => apiPost('/api/msauth/device-code'),
    pollMsAuth: (deviceCode) => apiPost('/api/msauth/poll', { deviceCode }),

    // === Java 运行时管理 ===
    detectJava: () => apiGet('/api/java/detect'),
    getJavaList: () => apiGet('/api/java/list'),
    getInstalledJava: () => apiGet('/api/java/installed'),
    getJavaInstallStatus: (sessionId) =>
        apiGet('/api/java/install-status', { sessionId }),
    autoInstallJava: (requiredVersion = 17) =>
        apiPost('/api/java/auto-install', { requiredVersion }),
    getJavaDownloadSources: () => apiGet('/api/java/download-sources'),
    downloadJava: (majorVersion) => apiPost('/api/java/download', { majorVersion }),
    cancelJavaDownload: (sessionId) => apiPost('/api/java/cancel', { sessionId }),
    getJavaDownloadStatus: (sessionId) =>
        apiGet('/api/java/download-status', { sessionId }),
    deleteJava: (javaHome) => apiPost('/api/java/delete', { javaHome }),
    addManualJava: (javaPath) => apiPost('/api/java/add-manual', { javaPath }),
    importJava: (type, path) => apiPost('/api/java/import', { type, path }),
    getJavaImportStatus: (sessionId) => apiGet('/api/java/import-status', { sessionId }),
    setCurrentJava: (javaPath) => apiPost('/api/java/set-current', { javaPath }),
    removeCustomJava: (javaHome, deleteFiles = false) => apiPost('/api/java/remove-custom', { javaHome, deleteFiles }),
    getOptimizedJvmArgs: (versionId) => apiGet('/api/jvm/optimize-args', { versionId }),
    generateCds: (versionId) => apiPost('/api/jvm/generate-cds', { versionId }),
    getCdsStatus: (versionId) => apiGet('/api/jvm/cds-status', { versionId }),

    // === 服务端状态 ===
    getStatus: () => apiGet('/api/status'),

    // === 文件系统操作 ===
    openFolder: (folder) => apiPost('/api/open-folder', { folder }),
    openInExplorer: (targetPath) => apiPost('/api/filesystem/open-in-explorer', { targetPath }),
    getDefaultModPath: (versionId) => apiGet('/api/filesystem/default-mod-path', versionId ? { versionId } : {}),
    getDefaultResourcePath: (type) => apiGet('/api/filesystem/default-resource-path', { type }),
    getQuickAccessPaths: () => apiGet('/api/filesystem/quick-access'),
    getDrives: () => apiGet('/api/filesystem/drives'),
    browseDirectory: (path, showHidden) =>
        apiPost('/api/filesystem/browse', { path, showHidden }),
    createDirectory: (parentPath, name) =>
        apiPost('/api/filesystem/create-directory', { parentPath, name }),

    // === 外部版本目录（整合包/其他启动器版本目录）===
    addExternalFolder: (folderPath, name = '') =>
        apiPost('/api/version/add-folder', { path: folderPath, name }),
    removeExternalFolder: (folderPath) =>
        apiPost('/api/version/remove-folder', { path: folderPath }),
    renameExternalFolder: (folderPath, name) =>
        apiPost('/api/version/rename-folder', { path: folderPath, name }),
    listExternalFolders: () => apiGet('/api/version/list-folders'),
    selectExternalFolder: () => apiGet('/api/version/select-folder'),
    autoDetectFolders: () => apiGet('/api/version/auto-detect-folders', {}, 120000),

    // === 整合包导出 ===
    exportModpack: (versionId, name, version, author, description, selectedKeys) =>
        apiPost('/api/version/export-modpack', { versionId, name, version, author, description, selectedKeys }),

    // === 模组依赖递归/版本查询 ===
    getDependenciesRecursive: (versionId, source = 'modrinth', gameVersion = '', loader = '') =>
        apiPost('/api/mods/get-dependencies-recursive', { versionId, source, gameVersion, loader }),
    getProjectVersions: (projectId, source = 'modrinth', gameVersion = '', loader = '') =>
        apiGet('/api/mods/project-versions', { projectId, source, gameVersion, loader }),

    // === EasyTier 下载 ===
    easytierDownload: () => apiPost('/api/easytier/download'),
    easytierDownloadStatus: (sessionId) => apiGet('/api/easytier/download-status', { sessionId }),

    // === 系统工具 ===
    createShortcut: (type) => apiPost('/api/create-shortcut', { type }),
    getScreenshots: (versionId) => apiGet('/api/screenshots', { versionId }),
    getMemoryInfo: () => apiGet('/api/system/memory-info'),

    // === 背景/头像图片 ===
    saveBackgroundImage: (dataUrl) => apiPost('/api/save-background', { dataUrl }),
    saveAvatarImage: (dataUrl) => apiPost('/api/save-avatar', { dataUrl }),
    clearBackgroundImage: () => apiPost('/api/clear-background'),
    clearAvatarImage: () => apiPost('/api/clear-avatar'),

    // === 资源搜索 ===
    searchResources: (query, type = 'modpack', loader = '', version = '', category = '', sort = 'downloads', limit = 15, offset = 0, source = '') =>
        apiGet('/api/resources/search', { query, type, loader, version, category, sort, limit, offset, source }),
    getResourceVersions: (projectId, source = 'modrinth', loader = '', gameVersion = '') =>
        apiGet('/api/resources/versions', { projectId, source, loader, gameVersion }),
    downloadResource: (versionId, projectId, projectType = 'mod', targetVersionId = '', savePath = '', customName = '', source = 'modrinth') =>
        apiPost('/api/resources/download', { versionId, projectId, projectType, targetVersionId, savePath, customName, source }, 120000),

    // === EasyTier 虚拟组网 ===
    easytierStatus: () => apiGet('/api/easytier/status'),
    easytierHost: (gamePort, playerName) => apiPost('/api/easytier/host', { gamePort, playerName }),
    easytierGuest: (roomCode, playerName) => apiPost('/api/easytier/guest', { roomCode, playerName }),
    easytierStop: () => apiPost('/api/easytier/stop', {}),
    easytierPeers: () => apiGet('/api/easytier/peers'),
    easytierLog: () => apiGet('/api/easytier/log'),

    checkModUpdates: (versionId) => apiPost('/api/mods/check-updates', { versionId }),

    // === 崩溃分析器 ===
    getCrashLogs: (version) => apiGet('/api/crash/logs', { version }),
    analyzeCrashFile: (filePath) => apiPost('/api/crash/analyze', { filePath }),
    getCrashLogContent: (path) => apiGet('/api/crash/log-content', { path }),
    exportCrashReport: (files, analysis) => apiPost('/api/crash/export', { files, analysis }),

    // === 崩溃日志导出 ===
    exportCrashLog: (versionId) => {
        if (_isTauri) {
            // Tauri 下通过 invoke 获取日志内容
            const query = versionId ? { versionId } : {};
            apiGet('/api/game/log/export', query).then(data => {
                if (data && data.content) {
                    const blob = new Blob([data.content], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = (data.fileName && data.fileName.endsWith('.txt')) ? data.fileName : `crash-log-${versionId || 'unknown'}.txt`;
                    a.click();
                    URL.revokeObjectURL(url);
                }
            }).catch(e => console.error('[API] 导出崩溃日志失败:', e));
        } else {
            const query = versionId ? `?versionId=${encodeURIComponent(versionId)}` : '';
            window.open(`${API_BASE}/api/game/log/export${query}`, '_blank');
        }
    },
};

// ============== 统一 IPC 面：把业务 API 挂到 window.bridge.api ==============
// 整个前端只有一个通信入口 window.bridge：
//   window.bridge.api.*           REST 业务方法（本文件 API 大对象）
//   window.bridge.apiProxy/invoke 底层传输
//   其余能力方法（窗口/系统/对话框/联机模块等）平铺在同层
window.API = API;
if (window.bridge) {
  window.bridge.api = API;
}

/* @versepc-protected: anti-ai-plagiarism-v1.0 */
