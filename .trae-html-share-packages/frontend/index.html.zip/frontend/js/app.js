/**
 * app.js - VersePC 前端总装入口
 *
 * 本文件职责：
 *   - 集中存放全局状态变量（currentVersionTab / allVersions / _favorites 等）
 *   - DOMContentLoaded 启动入口（调用 init / initSettingsPages / renderSponsors）
 *   - 不写具体页面逻辑（分散在 js/app/ 各子文件中）
 *
 * 边界约定（新增功能时务必遵守）：
 *   - HTML 模板 → js/vue/page-xxx.js
 *   - 交互逻辑  → js/app/xxx.js
 *   - 全局状态  → 本文件
 *   - 通用工具  → js/app/utils.js / ui-components.js / custom-select.js
 *
 * VersePC - Minecraft Launcher
 * Copyright (c) 2026 豆杰
 * SPDX-License-Identifier: GPL-3.0-only
 */

/* 全局状态变量 - 应用数据状态中心 */
let currentVersionTab = 'release';
let allVersions = [];
let installedVersions = [];
let versionIconsTimestamp = Date.now();
let currentModTab = 'installed-mods';
let modSearchOffset = 0;
let modSearchTotal = 0;
let modSearchQuery = '';
let modSearchResults = [];
let _modDownloadVersionId = '';
let currentInstallSessionId = null;
let msAuthPollInterval = null;
let currentLoaderType = 'fabric';
let gameLogEventSource = null;
let currentModDetailId = null;
let currentModDetailSource = 'modrinth';
let previousPage = null;
let modDetailHistory = [];
let modDetailVersions = [];
let modDownloadPollTimers = [];
let _isRestoringModDetail = false;
let _favorites = [];
let _currentFavId = '';
let _favMultiSelectMode = false;
let _favSelectedItems = new Set();
let _favSearchQuery = '';


let launchDepPollTimer = null;
let modMultiSelectMode = false;
let modSelectedIds = new Set();
let modSelectedVersions = new Map();

/* 优化基础设施 - DOM缓存、防抖节流等 */

/* DOM 缓存对象 */




/* 原有函数 */






/*
 * 平台功能显隐：仅在 Windows 可用/不生效的入口用 .win-only 标记隐藏。
 * 自更新在三平台均可用（Windows .bat、macOS .app 替换、Linux 二进制替换），
 * 因此 updater 相关区块不再隐藏，仅隐藏真正的 Windows 专属功能。
 */
function hideWinOnlyFeatures() {
  document.querySelectorAll('.win-only').forEach((el) => (el.style.display = 'none'));
}

document.addEventListener('DOMContentLoaded', () => {
  init();
  setTimeout(initSettingsPages, 500);
  renderSponsors();
  // 启动时不再自动弹出"更新公告"，新版本提示由更新检测单独处理，避免同时出现两个弹窗

  // 非 Windows 平台隐藏仅 Windows 可用/不生效的功能入口
  if (window.electronAPI && !window.electronAPI.isWindows) {
    hideWinOnlyFeatures();
    // 设置页模板延迟插入，稍后再补一次，确保自更新等入口被隐藏
    setTimeout(hideWinOnlyFeatures, 700);
  }
});

/* @versepc-protected: anti-ai-plagiarism-v1.0 */



















